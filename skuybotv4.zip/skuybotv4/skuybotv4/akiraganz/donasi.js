const donasi = () => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          DONASI BRO?  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱❉ *DONASI YOK* ❉⊰━━✿
┃   
┣━⊱ *GOPAY*
┣⊱ 6281328139682
┣━⊱ *GOPAY*
┣⊱ 6281328139682
┣━⊱ *PULSA*
┣⊱ 6281328139682
┃
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
